package gui;

import indexer.FieldSearcher;
import org.apache.lucene.queryparser.classic.ParseException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FieldSearchPanel extends JPanel {

    private JTextField fieldField;
    private JTextField queryField;
    private JTextPane resultsPane;
    private JButton nextButton;
    private JButton prevButton;
    private JButton sortButton;
    private List<String> results;
    private int currentIndex = 0;
    private static final int RESULTS_PER_PAGE = 10;
    private boolean ascending = true; 

    public FieldSearchPanel() {
        setLayout(new BorderLayout());

        // dhmioyrgia parathyroy anazhthshs
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        fieldField = new JTextField();                           // eisagwgh pedioy anazhthshs
        queryField = new JTextField();                           // eisagwgh erwthmatos
        JButton searchButton = new JButton("Search");

        inputPanel.add(new JLabel("Field: "));
        inputPanel.add(fieldField);
        inputPanel.add(new JLabel("Query: "));
        inputPanel.add(queryField);
        inputPanel.add(searchButton);

        // dhmioyrgia xwroy emfanishs apotelesmatwn
        resultsPane = new JTextPane();
        resultsPane.setContentType("text/html");
        resultsPane.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsPane);
        scrollPane.setPreferredSize(new Dimension(600, 400)); 

        // 
        JPanel navPanel = new JPanel(new FlowLayout());
        prevButton = new JButton("Previous");                 // koympi "previous"
        nextButton = new JButton("Next");                     // koympi "next"
        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
        navPanel.add(prevButton);
        navPanel.add(nextButton);

        
        sortButton = new JButton("Sort by Year");            // dhmioyrgia koympi taksinomhshs
        navPanel.add(sortButton);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(navPanel, BorderLayout.SOUTH);

        
        searchButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                performFieldSearch();
            }
        });

        
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentIndex -= RESULTS_PER_PAGE;
                updateResults();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                currentIndex += RESULTS_PER_PAGE;
                updateResults();
            }
        });

       
        sortButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                ascending = !ascending;
                sortResults();
                updateResults();
            }
        });
    }

    // ektelesh anazhthshs
    private void performFieldSearch() {
        String field = fieldField.getText();
        String queryStr = queryField.getText();
        if (field.isEmpty() || queryStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String indexDir = "C:\\index"; 
        try {
            FieldSearcher searcher = new FieldSearcher(indexDir);
            results = searcher.search(field, queryStr);
            currentIndex = 0;
            updateResults();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error performing field search: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void sortResults() {
        if (results != null && !results.isEmpty()) {
            Collections.sort(results, new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    int year1 = extractYear(o1);
                    int year2 = extractYear(o2);
                    return ascending ? Integer.compare(year1, year2) : Integer.compare(year2, year1);
                }
            });
        }
    }

    private int extractYear(String result) {
       
        String yearPrefix = "<b>Year:</b> ";
        int yearIndex = result.indexOf(yearPrefix);
        if (yearIndex != -1) {
            int start = yearIndex + yearPrefix.length();
            int end = result.indexOf("<", start);
            return Integer.parseInt(result.substring(start, end).trim());
        }
        return Integer.MIN_VALUE; 
    }

    // enhmerwsh epistrefomenwn apotelesmatwn
    private void updateResults() {
        if (results == null || results.isEmpty()) {
            resultsPane.setText("No results found.");
            prevButton.setEnabled(false);
            nextButton.setEnabled(false);
            return;
        }

        StringBuilder displayResults = new StringBuilder();
        displayResults.append("<html>");
        int endIndex = Math.min(currentIndex + RESULTS_PER_PAGE, results.size());
        for (int i = currentIndex; i < endIndex; i++) {
            displayResults.append(results.get(i)).append("<br><br>");
        }
        displayResults.append("</html>");

        resultsPane.setText(displayResults.toString());

        prevButton.setEnabled(currentIndex > 0);
        nextButton.setEnabled(endIndex < results.size());
    }
}
