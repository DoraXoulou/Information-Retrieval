package gui;

import indexer.SearchHistoryLogger;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class HistoryPanel extends JPanel {

    // Orizoun to grafiko stoixeio gia tin emfanisi tis istorias
    private JTextArea historyArea;

    public HistoryPanel() {
        setLayout(new BorderLayout());

        // Dimiourgia tis perioxis emfanisis istorias
        historyArea = new JTextArea();
        historyArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(historyArea);

        add(scrollPane, BorderLayout.CENTER);

        // Dimiourgia koumpiou ananewsis
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadHistory());
        add(refreshButton, BorderLayout.SOUTH);

        // Fortwsi tis istorias kata tin dimiourgia tou panel
        loadHistory();
    }

    // Methodos fortwsis istorias
    private void loadHistory() {
        try {
            // Pairnei tin istoria apo to SearchHistoryLogger
            List<String> history = SearchHistoryLogger.getHistory();
            StringBuilder displayText = new StringBuilder();
            for (String entry : history) {
                displayText.append(entry).append("\n");
            }
            historyArea.setText(displayText.toString());
        } catch (IOException e) {
            e.printStackTrace();
            // Emfanizei minima lathous an iparxei provlima me tin fortwsi tis istorias
            JOptionPane.showMessageDialog(this, "Error loading history: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
