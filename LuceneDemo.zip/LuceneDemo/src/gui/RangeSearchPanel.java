package gui;

import indexer.RangeSearcher;
import org.apache.lucene.queryparser.classic.ParseException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RangeSearchPanel extends JPanel {

    // Orizoun ta grafika stoixeia tou panel
    private JTextField fieldField;
    private JTextField lowerTermField;
    private JTextField upperTermField;
    private JTextPane resultsPane;
    private JButton nextButton;
    private JButton prevButton;
    private JButton sortButton;
    private List<String> results;
    private int currentIndex = 0;
    private static final int RESULTS_PER_PAGE = 10;
    private boolean ascending = true; // Simadia taxinomisis

    public RangeSearchPanel() {
        setLayout(new BorderLayout());

        // Dimiourgia tou panel eisagogis anazitisis
        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        fieldField = new JTextField();
        lowerTermField = new JTextField();
        upperTermField = new JTextField();
        JButton searchButton = new JButton("Search");

        inputPanel.add(new JLabel("Field: "));
        inputPanel.add(fieldField);
        inputPanel.add(new JLabel("Lower Term: "));
        inputPanel.add(lowerTermField);
        inputPanel.add(new JLabel("Upper Term: "));
        inputPanel.add(upperTermField);
        inputPanel.add(searchButton);

        // Dimiourgia tis perioxis emfanisis apotelesmaton me kathorismeni ipsos kai scroll pane
        resultsPane = new JTextPane();
        resultsPane.setContentType("text/html");
        resultsPane.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsPane);
        scrollPane.setPreferredSize(new Dimension(600, 400)); // Kathorismos protimomenou megethous gia sosto scrolling

        // Dimiourgia koumpiwn pleeimobisis
        JPanel navPanel = new JPanel(new FlowLayout());
        prevButton = new JButton("Previous");
        nextButton = new JButton("Next");
        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
        navPanel.add(prevButton);
        navPanel.add(nextButton);

        // Dimiourgia koumpiou taksinomisis
        sortButton = new JButton("Sort by Year");
        navPanel.add(sortButton);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(navPanel, BorderLayout.SOUTH);

        // Prosthiki listener gia to koumpi anazitisis
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performRangeSearch();
            }
        });

        // Prosthiki listener gia ta koumpia pleeimobisis
        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentIndex -= RESULTS_PER_PAGE;
                updateResults();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentIndex += RESULTS_PER_PAGE;
                updateResults();
            }
        });

        // Prosthiki listener gia to koumpi taksinomisis
        sortButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ascending = !ascending;
                sortResults();
                updateResults();
            }
        });
    }

    // Methodos pou ektelei tin anazitisi evrous
    private void performRangeSearch() {
        String field = fieldField.getText();
        String lowerTerm = lowerTermField.getText();
        String upperTerm = upperTermField.getText();
        if (field.isEmpty() || lowerTerm.isEmpty() || upperTerm.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String indexDir = "C:\\index"; // Ananewste auto to monopati
        try {
            RangeSearcher searcher = new RangeSearcher(indexDir);
            results = searcher.search(field, lowerTerm, upperTerm);
            currentIndex = 0;
            updateResults();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error performing range search: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Methodos pou taksinomei ta apotelesmata
    private void sortResults() {
        if (results != null && !results.isEmpty()) {
            Collections.sort(results, new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    int year1 = extractYear(o1);
                    int year2 = extractYear(o2);
                    return ascending ? Integer.compare(year1, year2) : Integer.compare(year2, year1);
                }
            });
        }
    }

    // Methodos pou epekteinei to etos apo ena apotelesma
    private int extractYear(String result) {
        // Exairestei to etos apo to string apotelesmatos ipothetondas oti einai stin morfi "...<b>Year:</b> XXXX..."
        String yearPrefix = "<b>Year:</b> ";
        int yearIndex = result.indexOf(yearPrefix);
        if (yearIndex != -1) {
            int start = yearIndex + yearPrefix.length();
            int end = result.indexOf("<", start);
            return Integer.parseInt(result.substring(start, end).trim());
        }
        return Integer.MIN_VALUE; // Epistrefei mia poli mikri timi an den vrethei to etos
    }

    // Methodos pou ananewnei ta apotelesmata
    private void updateResults() {
        if (results == null || results.isEmpty()) {
            resultsPane.setText("No results found.");
            prevButton.setEnabled(false);
            nextButton.setEnabled(false);
            return;
        }

        StringBuilder displayResults = new StringBuilder();
        displayResults.append("<html>");
        int endIndex = Math.min(currentIndex + RESULTS_PER_PAGE, results.size());
        for (int i = currentIndex; i < endIndex; i++) {
            displayResults.append(results.get(i)).append("<br><br>");
        }
        displayResults.append("</html>");

        resultsPane.setText(displayResults.toString());

        prevButton.setEnabled(currentIndex > 0);
        nextButton.setEnabled(endIndex < results.size());
    }
}
