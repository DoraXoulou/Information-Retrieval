package gui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("Indexer Search Application");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create tabs for different search panels
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Search", new SearchPanel());
        tabbedPane.addTab("Range Search", new RangeSearchPanel());
        tabbedPane.addTab("Field Search", new FieldSearchPanel());
        tabbedPane.addTab("History", new HistoryPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        });
    }
}
