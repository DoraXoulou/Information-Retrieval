package gui;

import indexer.Searcher;
import org.apache.lucene.queryparser.classic.ParseException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SearchPanel extends JPanel {

    private JTextField queryField;
    private JTextPane resultsPane;
    private JButton nextButton;
    private JButton prevButton;
    private JButton sortButton;
    private List<String> results;
    private int currentIndex = 0;
    private static final int RESULTS_PER_PAGE = 10;
    private boolean ascending = true;

    public SearchPanel() {
        setLayout(new BorderLayout());

        
        JPanel inputPanel = new JPanel(new BorderLayout());         // dhmiourgia toy parathyroy anazhthshs
        queryField = new JTextField();
        JButton searchButton = new JButton("Search");
        inputPanel.add(new JLabel("Query: "), BorderLayout.WEST);
        inputPanel.add(queryField, BorderLayout.CENTER);
        inputPanel.add(searchButton, BorderLayout.EAST);

        
        resultsPane = new JTextPane();                              // dhmiourgia xwroy emfanishs apotelesmatwn
        resultsPane.setContentType("text/html");
        resultsPane.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultsPane);
        scrollPane.setPreferredSize(new Dimension(600, 400));       // megethos parathyroy

       
        JPanel navPanel = new JPanel(new FlowLayout());
        prevButton = new JButton("Previous");                       // dhmiourgia koympi plohghshs "previous"
        nextButton = new JButton("Next");                           // dhmiourgia koympi plohghshs "next" 
        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
        navPanel.add(prevButton);
        navPanel.add(nextButton);

        
        sortButton = new JButton("Sort by Year");                  // dhmiourgia koympi taksinomhsh
        navPanel.add(sortButton);

        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(navPanel, BorderLayout.SOUTH);

       
        searchButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                performSearch();
            }
        });

        
        prevButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                currentIndex -= RESULTS_PER_PAGE;
                updateResults();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                currentIndex += RESULTS_PER_PAGE;
                updateResults();
            }
        });

        
        sortButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                ascending = !ascending;
                sortResults();
                updateResults();
            }
        });
    }

    // ektelesh anazhthshs
    private void performSearch() {
        String queryStr = queryField.getText();
        if (queryStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a query.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String indexDir = "C:\\index"; 
        try {
            Searcher searcher = new Searcher(indexDir);
            results = searcher.search(queryStr);
            currentIndex = 0;
            updateResults();
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error performing search: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //taksinomhsh apotelesmatwn
    private void sortResults() {
        if (results != null && !results.isEmpty()) {
            Collections.sort(results, new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    int year1 = extractYear(o1);
                    int year2 = extractYear(o2);
                    return ascending ? Integer.compare(year1, year2) : Integer.compare(year2, year1);
                }
            });
        }
    }

    private int extractYear(String result) {
        
        String yearPrefix = "<b>Year:</b> ";
        int yearIndex = result.indexOf(yearPrefix);
        if (yearIndex != -1) {
            int start = yearIndex + yearPrefix.length();
            int end = result.indexOf("<", start);
            return Integer.parseInt(result.substring(start, end).trim());
        }
        return Integer.MIN_VALUE; 
    }
    
    // enhmerwsh epistrefomenwn apotelesmatwn
    private void updateResults() {
        if (results == null || results.isEmpty()) {
            resultsPane.setText("No results found.");
            prevButton.setEnabled(false);
            nextButton.setEnabled(false);
            return;
        }

        StringBuilder displayResults = new StringBuilder();
        displayResults.append("<html>");
        int endIndex = Math.min(currentIndex + RESULTS_PER_PAGE, results.size());
        for (int i = currentIndex; i < endIndex; i++) {
            displayResults.append(results.get(i)).append("<br><br>");
        }
        displayResults.append("</html>");

        resultsPane.setText(displayResults.toString());

        prevButton.setEnabled(currentIndex > 0);
        nextButton.setEnabled(endIndex < results.size());
    }
}
