package indexer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SearchHistoryLogger {

    // Orismos tou monopatiou tou arxeiou katagrafis kai tou format tis imerominias
    private static final String LOG_FILE_PATH = "search_history.txt";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // Methodos gia tin katagrafi mia apli anazitisi
    public static void logSearch(String queryStr) {
        log("Query: " + queryStr);
    }

    // Methodos gia tin katagrafi anazitisis evrous
    public static void logSearch(String field, String lowerTerm, String upperTerm) {
        log(field + " | Range: [" + lowerTerm + " TO " + upperTerm + "]");
    }

    // Methodos gia tin katagrafi anazitisis me sugkekrimeno pedio
    public static void logSearch(String field, String queryStr) {
        log("Field: " + field + " | Query: " + queryStr);
    }

    // Idiotiki methodos gia tin katagrafi minimatos sto arxeio
    private static void log(String message) {
        String timestamp = LocalDateTime.now().format(DATE_TIME_FORMATTER);
        String logEntry = timestamp + " | " + message;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE_PATH, true))) {
            writer.write(logEntry);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Methodos gia tin anaktisi olis tis istorias anazitiseon
    public static List<String> getHistory() throws IOException {
        return Files.readAllLines(Paths.get(LOG_FILE_PATH));
    }
}
