package indexer;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.WhitespaceTokenizer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.en.PorterStemFilter;
import org.apache.lucene.analysis.miscellaneous.ASCIIFoldingFilter;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.synonym.SynonymGraphFilter;
import org.apache.lucene.analysis.synonym.SynonymMap;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.CharsRef;
import org.apache.lucene.util.IOUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.Normalizer;

public class Indexer {

    private IndexWriter writer;

    // Custom Analyzer me diafores texnikes epigrafis keimenou
    private static class CustomAnalyzer extends Analyzer {

        // Methodos gia na dimiourgisei ena SynonymMap
        private SynonymMap buildSynonymMap() throws IOException {
            SynonymMap.Builder builder = new SynonymMap.Builder(true);
            builder.add(new CharsRef("quick"), new CharsRef("fast"), true);
            builder.add(new CharsRef("jumps"), new CharsRef("leaps"), true);
            SynonymMap synonymMap = builder.build();
            return synonymMap;
        }

        @Override
        protected TokenStreamComponents createComponents(String fieldName) {
            WhitespaceTokenizer source = new WhitespaceTokenizer();
            TokenStream filter = new LowerCaseFilter(source);
            filter = new StopFilter(filter, EnglishAnalyzer.ENGLISH_STOP_WORDS_SET);
            filter = new PorterStemFilter(filter);
            filter = new ASCIIFoldingFilter(filter);
            try {
                filter = new SynonymGraphFilter(filter, buildSynonymMap(), true);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return new TokenStreamComponents(source, filter);
        }
    }

    // Arxikopoiisi IndexWriter me Custom Analyzer
    public Indexer(String indexDir) throws IOException {
        Directory dir = FSDirectory.open(Paths.get(indexDir));
        Analyzer analyzer = new CustomAnalyzer();
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        writer = new IndexWriter(dir, config);
    }

    // Kleisimo tou IndexWriter
    public void close() throws IOException {
        writer.close();
    }

    // Methodos gia na kanonikoποιήσει ta keimena
    private String normalizeText(String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    // Methodos gia na kanei index ena arxeio CSV
    private void indexFile(File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // Skip header line
            while ((line = reader.readLine()) != null) {
                int firstCommaIndex = line.indexOf(",");
                int secondCommaIndex = line.indexOf(",", firstCommaIndex + 1);
                int thirdCommaIndex = line.indexOf(",", secondCommaIndex + 1);

                if (firstCommaIndex != -1 && secondCommaIndex != -1) {
                    String year = line.substring(0, firstCommaIndex).trim();
                    String title = line.substring(firstCommaIndex + 1, secondCommaIndex).trim();
                    String abstractText = "";
                    String fullText = "";

                    if (thirdCommaIndex != -1) {
                        abstractText = line.substring(secondCommaIndex + 1, thirdCommaIndex).trim();
                        fullText = line.substring(thirdCommaIndex + 1).trim();
                    } else {
                        fullText = line.substring(secondCommaIndex + 1).trim();
                    }

                    Document doc = new Document();
                    doc.add(new TextField("year", normalizeText(year), Field.Store.YES));
                    doc.add(new TextField("title", normalizeText(title), Field.Store.YES));
                    doc.add(new TextField("abstract", normalizeText(abstractText), Field.Store.YES));
                    doc.add(new TextField("full_text", normalizeText(fullText), Field.Store.YES));
                    writer.addDocument(doc);
                }
            }
        }
    }

    // Methodos gia na kanei index ola ta arxeia se ena fakelo
    public int index(String dataDir) throws IOException {
        File[] files = new File(dataDir).listFiles();
        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".csv")) {
                indexFile(file);
            }
        }
        return writer.getDocStats().numDocs;
    }

    public static void main(String[] args) {
        String indexDir = "C:\\index"; // Ananewste auto to monopati
        String dataDir = "C:\\Users\\nikol\\Documents\\Anakthsh_plhroforias";
        Indexer indexer = null;
        try {
            indexer = new Indexer(indexDir);
            int numIndexed = indexer.index(dataDir);
            indexer.close();
            System.out.println("Indexed " + numIndexed + " files");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
