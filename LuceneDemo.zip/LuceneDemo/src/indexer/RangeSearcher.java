package indexer;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class RangeSearcher {

    private IndexSearcher searcher;
    private StandardAnalyzer analyzer;

    // Arxikopoiisi IndexSearcher kai StandardAnalyzer
    public RangeSearcher(String indexDir) throws IOException {
        Directory dir = FSDirectory.open(Paths.get(indexDir));
        IndexReader reader = DirectoryReader.open(dir);
        searcher = new IndexSearcher(reader);
        analyzer = new StandardAnalyzer();
    }

    // Methodos gia anazitisi evrous kai epistrofi apotelesmaton os lista apo strings
    public List<String> search(String field, String lowerTerm, String upperTerm) throws IOException, ParseException {
        Query query = TermRangeQuery.newStringRange(field, lowerTerm, upperTerm, true, true);

        TopDocs results = searcher.search(query, Integer.MAX_VALUE); // Anaktisi olwn ton apotelesmaton
        List<Document> docs = new ArrayList<>();
        for (ScoreDoc scoreDoc : results.scoreDocs) {
            docs.add(searcher.doc(scoreDoc.doc));
        }

        // Dimiourgia listas apotelesmaton me ta keyword simeia
        List<String> resultStrings = new ArrayList<>();
        for (Document doc : docs) {
            StringBuilder resultString = new StringBuilder();
            resultString.append("<html><b>Title:</b> ").append(highlightKeywords(doc.get("title"), lowerTerm)).append("<br>");
            resultString.append("<b>Year:</b> ").append(doc.get("year")).append("<br>");
            resultString.append("<b>Abstract:</b> ").append(highlightKeywords(doc.get("abstract"), lowerTerm)).append("<br>");
            resultString.append("<b>Full Text:</b> ").append(highlightKeywords(doc.get("full_text"), lowerTerm)).append("<br>");
            resultString.append("-----------------------------------------------------<br></html>");
            resultStrings.add(resultString.toString());
        }

        // Katagrafi tis anazitisis stin istoria
        SearchHistoryLogger.logSearch(field, lowerTerm, upperTerm);

        return resultStrings;
    }

    // Methodos gia na anadeixnei ta keywords
    private String highlightKeywords(String text, String keyword) {
        return text.replaceAll("(?i)" + keyword, "<b>$0</b>");
    }
}
