package indexer;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Searcher {

    private IndexSearcher searcher;
    private QueryParser parser;

    // Arxikopoiisi IndexSearcher kai QueryParser
    public Searcher(String indexDir) throws IOException {
        Directory dir = FSDirectory.open(Paths.get(indexDir));
        IndexReader reader = DirectoryReader.open(dir);
        searcher = new IndexSearcher(reader);
        parser = new QueryParser("full_text", new StandardAnalyzer());
    }

    // Anazitisi sto index kai epistrofi apotelesmaton os lista apo strings
    public List<String> search(String queryStr) throws IOException, ParseException {
        Query query = parser.parse(queryStr);
        TopDocs results = searcher.search(query, Integer.MAX_VALUE); // Anaktisi olwn ton apotelesmaton
        List<Document> docs = new ArrayList<>();
        for (ScoreDoc scoreDoc : results.scoreDocs) {
            docs.add(searcher.doc(scoreDoc.doc));
        }

        // Dimiourgia listas apotelesmaton me ta keyword simeia
        List<String> resultStrings = new ArrayList<>();
        for (Document doc : docs) {
            StringBuilder resultString = new StringBuilder();
            resultString.append("<html><b>Title:</b> ").append(highlightKeywords(doc.get("title"), queryStr)).append("<br>");
            resultString.append("<b>Year:</b> ").append(doc.get("year")).append("<br>");
            resultString.append("<b>Abstract:</b> ").append(highlightKeywords(doc.get("abstract"), queryStr)).append("<br>");
            resultString.append("<b>Full Text:</b> ").append(highlightKeywords(doc.get("full_text"), queryStr)).append("<br>");
            resultString.append("-----------------------------------------------------<br></html>");
            resultStrings.add(resultString.toString());
        }

        // Katagrafi tis anazitisis stin istoria
        SearchHistoryLogger.logSearch(queryStr);

        return resultStrings;
    }

    // Methodos gia na anadeixnei ta keywords
    private String highlightKeywords(String text, String keyword) {
        return text.replaceAll("(?i)" + keyword, "<b>$0</b>");
    }
}
